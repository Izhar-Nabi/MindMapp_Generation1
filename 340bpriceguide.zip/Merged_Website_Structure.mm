<?xml version='1.0' encoding='utf-8'?>
<map version="1.0.1">
  <node TEXT="Home">
    <node TEXT="Header">
      <node TEXT="Navigation Links">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/" />
        <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search">
          <node TEXT="Frequently Searched Products">
            <node TEXT="ADVAIR HFA 230-21 MCG INHALER">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#486" />
            </node>
            <node TEXT="BREO ELLIPTA 100-25 MCG INHALR">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#488" />
            </node>
            <node TEXT="BUTRANS 5 MCG/HR PATCH">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#14857" />
            </node>
            <node TEXT="DULERA 200 MCG-5 MCG INHALER">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#13331" />
            </node>
            <node TEXT="FARXIGA 10 MG TABLET">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#116" />
            </node>
            <node TEXT="JANUVIA 100 MG TABLET">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#534" />
            </node>
            <node TEXT="JARDIANCE 10 MG TABLET">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#185" />
            </node>
            <node TEXT="LANTUS SOLOSTAR 100 UNIT/ML">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#588" />
            </node>
            <node TEXT="LIDOCAINE 5% PATCH">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2310" />
            </node>
            <node TEXT="LYRICA 100 MG CAPSULE">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19309" />
            </node>
            <node TEXT="PROAIR RESPICLICK 90 MCG INHLR">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#18373" />
            </node>
            <node TEXT="TRADJENTA 5 MG TABLET">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#167" />
            </node>
            <node TEXT="TRULICITY 1.5 MG/0.5 ML PEN">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#365" />
            </node>
            <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PEN">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#13214" />
            </node>
            <node TEXT="XARELTO 10 MG TABLET">
              <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9718" />
            </node>
          </node>
          <node TEXT="Comments Section">
            <node TEXT="Comment Form">
              <node TEXT="Input: What do you think?" />
              <node TEXT="Button: Post" />
            </node>
            <node TEXT="Comments List">
              <node TEXT="User questions and expert replies about 340B pricing, supply, coverage, and usage." />
              <node TEXT="Button: Load more comments" />
            </node>
          </node>
          <node TEXT="Assign Pharmacy Notice">
            <node TEXT="Please assign pharmacy from the portal first" />
          </node>
          <node TEXT="Search Filters Form">
            <node TEXT="Select Pharmacy" />
            <node TEXT="Select Patient Group" />
            <node TEXT="Select Formulary" />
            <node TEXT="Button: Clear All Data" />
          </node>
        </node>
        <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news">
          <node TEXT="Featured Articles">
            <node TEXT="Weekly Product Shortages">
              <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" />
            </node>
            <node TEXT="Manufacturer 340B Restrictions for Oregon">
              <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" />
            </node>
            <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026">
              <node TEXT="Novo Nordisk recently announced changes to the eligibility criteria for its Patient Assistance Program for 2026." />
              <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" />
            </node>
            <node TEXT="Bausch Health Exits the 340B Drug Pricing Program">
              <node TEXT="Bausch Health ended its participation in the 340B Drug Pricing Program effective October 1, 2025." />
              <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" />
            </node>
          </node>
          <node TEXT="More Articles">
            <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September">
              <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September." LINK="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" />
            </node>
            <node TEXT="Communication from BPHC announcing new award terms">
              <node TEXT="Communication from BPHC announcing new award terms." LINK="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" />
            </node>
            <node TEXT="Rite Aid Winds Down 340B Operations">
              <node TEXT="Rite Aid Winds Down 340B Operations." LINK="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" />
            </node>
            <node TEXT="Continued Brand Name Victoza Shortages">
              <node TEXT="Continued Brand Name Victoza Shortages." LINK="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" />
            </node>
          </node>
          <node TEXT="Pagination">
            <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4" />
            <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8" />
            <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12" />
            <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16" />
            <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20" />
            <node TEXT="7" LINK="https://www.340bpriceguide.net/articles-news?start=24" />
            <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4" />
            <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=24" />
          </node>
        </node>
        <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us">
          <node TEXT="340B Price Guide Overview">
            <node TEXT="Summary: Customized publication for 340B drug discount program, helping entities interpret drug prices and patient care impact." />
          </node>
          <node TEXT="340B Guided Services">
            <node TEXT="Summary: Consulting for covered entities on 340B program management and best practices, serving a range of health organizations." />
          </node>
          <node TEXT="Client Testimonials">
            <node TEXT="Summary: Feedback from healthcare professionals highlighting the benefits and impact of the 340B Price Guide." />
          </node>
          <node TEXT="Organizations Served">
            <node TEXT="Summary: Logos of various health organizations and clinics that have used 340B Price Guide services." />
          </node>
        </node>
        <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us">
          <node TEXT="Contact Form">
            <node TEXT="Name" />
            <node TEXT="Email" />
            <node TEXT="Company" />
            <node TEXT="Address" />
            <node TEXT="City, State Zip" />
            <node TEXT="Phone" />
            <node TEXT="Inquiry Type" />
            <node TEXT="Comment or Question" />
            <node TEXT="Captcha" />
            <node TEXT="Submit Button" />
          </node>
          <node TEXT="Contact Information Summary">
            <node TEXT="Address, phone, and email for 340B Price Guide" />
          </node>
        </node>
        <node TEXT="Profile" LINK="https://www.340bpriceguide.net/my-profile">
          <node TEXT="User Profile Overview">
            <node TEXT="Ali Zain (Online) - Profile summary and status" />
          </node>
          <node TEXT="Details Section">
            <node TEXT="Username: Ali, First Name: Ali, Last Name: Zain, Clinic/Hospital: ABC" />
            <node TEXT="Email Address">
              <node TEXT="alizainsharif48@gmail.com" />
            </node>
          </node>
          <node TEXT="Edit Profile">
            <node TEXT="Edit Profile" />
          </node>
        </node>
        <node TEXT="Logout" LINK="https://www.340bpriceguide.net/logout" />
        <node TEXT="SecureMsg" LINK="https://www.340bpriceguide.net/secure-message">
          <node TEXT="Send Secure Message Form">
            <node TEXT="Patient Name" />
            <node TEXT="Patient DOB" />
            <node TEXT="Pharmacy" />
            <node TEXT="Medication and Strength" />
            <node TEXT="Prescription Number (if available)" />
            <node TEXT="Contact at the pharmacy (if available)" />
            <node TEXT="Problem/Comment" />
            <node TEXT="SUBMIT Button" />
          </node>
        </node>
      </node>
      <node TEXT="Search Bar Form">
        <node TEXT="Text Field: Enter a medication" />
        <node TEXT="Button: FIND 340B PRICES" />
      </node>
    </node>
    <node TEXT="Main Content">
      <node TEXT="Image Carousel">
        <node TEXT="Community Health Centers Of Lane County" />
        <node TEXT="Eugene, Oregon" />
      </node>
      <node TEXT="What is 340B?">
        <node TEXT="Description: For the past 25 years, 340B has helped provide low-cost medications and better health..." />
        <node TEXT="Learn More" LINK="https://www.340bpriceguide.net/articles-news/50-what-is-340b" />
      </node>
      <node TEXT="Weekly Product Shortages">
        <node TEXT="Weekly Product Shortages" LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" />
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="Useful Links">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/" />
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" />
        <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news" />
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" />
      </node>
      <node TEXT="Information">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" />
      </node>
      <node TEXT="Contact Us">
        <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" />
        <node TEXT="Address: 501 Fourth Street, #854, Lake Oswego, OR 97034" />
        <node TEXT="Phone: (503)298-0681" />
      </node>
      <node TEXT="External Resources">
        <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa" />
      </node>
    </node>
  </node>
</map>