<node TEXT="contact">
    <node TEXT="Main Content">
      <node TEXT="Contact Form">
        <node TEXT="Name Field"/>
        <node TEXT="Email Field"/>
        <node TEXT="Company Field"/>
        <node TEXT="Address Field"/>
        <node TEXT="City, State Zip Field"/>
        <node TEXT="Phone Field"/>
        <node TEXT="Inquiry Type Dropdown"/>
        <node TEXT="Comment or Question Field"/>
        <node TEXT="Captcha Field"/>
        <node TEXT="SUBMIT" LINK="https://www.340bpriceguide.net/contact-us"/>
      </node>
    </node>
  </node>