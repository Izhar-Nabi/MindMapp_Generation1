<node TEXT="search">
    <node TEXT="Main Content">
      <node TEXT="Frequently Searched Products">
        <node TEXT="ADVAIR HFA 230-21 MCG INHALER" LINK="https://www.340bpriceguide.net/340b-search#486"/>
        <node TEXT="BREO ELLIPTA 100-25 MCG INHALR" LINK="https://www.340bpriceguide.net/340b-search#488"/>
        <node TEXT="BUTRANS 5 MCG/HR PATCH" LINK="https://www.340bpriceguide.net/340b-search#14857"/>
        <node TEXT="DULERA 200 MCG-5 MCG INHALER" LINK="https://www.340bpriceguide.net/340b-search#13331"/>
        <node TEXT="FARXIGA 10 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#116"/>
        <node TEXT="JANUVIA 100 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#534"/>
        <node TEXT="JARDIANCE 10 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#185"/>
        <node TEXT="LANTUS SOLOSTAR 100 UNIT/ML" LINK="https://www.340bpriceguide.net/340b-search#588"/>
        <node TEXT="LIDOCAINE 5% PATCH" LINK="https://www.340bpriceguide.net/340b-search#2310"/>
        <node TEXT="LYRICA 100 MG CAPSULE" LINK="https://www.340bpriceguide.net/340b-search#19309"/>
        <node TEXT="PROAIR RESPICLICK 90 MCG INHLR" LINK="https://www.340bpriceguide.net/340b-search#18373"/>
        <node TEXT="TRADJENTA 5 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#167"/>
        <node TEXT="TRULICITY 1.5 MG/0.5 ML PEN" LINK="https://www.340bpriceguide.net/340b-search#365"/>
        <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PEN" LINK="https://www.340bpriceguide.net/340b-search#13214"/>
        <node TEXT="XARELTO 10 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#9718"/>
      </node>
      <node TEXT="Comments Section">
        <node TEXT="Users ask questions and share experiences about 340B pricing, pharmacy coverage, and medication availability."/>
        <node TEXT="Search Comments Form">
          <node TEXT="Search Comments Field"/>
          <node TEXT="Sort By Dropdown"/>
        </node>
        <node TEXT="Load more comments Button"/>
      </node>
    </node>
  </node>