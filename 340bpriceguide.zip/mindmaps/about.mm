<node TEXT="about">
    <node TEXT="Main Content">
      <node TEXT="340B Price Guide Overview">
        <node TEXT="Customized publication for health organizations to interpret 340B drug prices and their impact."/>
      </node>
      <node TEXT="340B Guided Services">
        <node TEXT="Independent consulting and guidance for 340B program management and best practices."/>
        <node TEXT="Welcomes inquiries from all covered entities."/>
      </node>
      <node TEXT="Client Logos">
        <node TEXT="Visual display of partner and client health organizations."/>
      </node>
      <node TEXT="Client Testimonials">
        <node TEXT="Testimonials highlight cost savings, improved patient care, and ease of use for 340B Price Guide."/>
      </node>
    </node>
  </node>