<map version="1.0.1">
  <node TEXT="SecureMsg">
    <node TEXT="Send Secure Message Form">
      <node TEXT="Patient Name"/>
      <node TEXT="Patient DOB"/>
      <node TEXT="Pharmacy"/>
      <node TEXT="Medication and Strength"/>
      <node TEXT="Prescription Number (if available)"/>
      <node TEXT="Contact at the pharmacy (if available)"/>
      <node TEXT="Problem/Comment"/>
      <node TEXT="SUBMIT Button"/>
    </node>
  </node>
</map>