<map version="1.0.1">
  <node TEXT="About">
    <node TEXT="340B Price Guide Overview">
      <node TEXT="Summary: Customized publication for 340B drug discount program, helping entities interpret drug prices and patient care impact."/>
    </node>
    <node TEXT="340B Guided Services">
      <node TEXT="Summary: Consulting for covered entities on 340B program management and best practices, serving a range of health organizations."/>
    </node>
    <node TEXT="Client Testimonials">
      <node TEXT="Summary: Feedback from healthcare professionals highlighting the benefits and impact of the 340B Price Guide."/>
    </node>
    <node TEXT="Organizations Served">
      <node TEXT="Summary: Logos of various health organizations and clinics that have used 340B Price Guide services."/>
    </node>
  </node>
</map>