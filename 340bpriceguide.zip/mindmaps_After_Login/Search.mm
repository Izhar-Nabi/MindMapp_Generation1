<map version="1.0.1">
  <node TEXT="Search">
    <node TEXT="Frequently Searched Products">
      <node TEXT="ADVAIR HFA 230-21 MCG INHALER">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#486"/>
      </node>
      <node TEXT="BREO ELLIPTA 100-25 MCG INHALR">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#488"/>
      </node>
      <node TEXT="BUTRANS 5 MCG/HR PATCH">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#14857"/>
      </node>
      <node TEXT="DULERA 200 MCG-5 MCG INHALER">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#13331"/>
      </node>
      <node TEXT="FARXIGA 10 MG TABLET">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#116"/>
      </node>
      <node TEXT="JANUVIA 100 MG TABLET">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#534"/>
      </node>
      <node TEXT="JARDIANCE 10 MG TABLET">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#185"/>
      </node>
      <node TEXT="LANTUS SOLOSTAR 100 UNIT/ML">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#588"/>
      </node>
      <node TEXT="LIDOCAINE 5% PATCH">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2310"/>
      </node>
      <node TEXT="LYRICA 100 MG CAPSULE">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19309"/>
      </node>
      <node TEXT="PROAIR RESPICLICK 90 MCG INHLR">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#18373"/>
      </node>
      <node TEXT="TRADJENTA 5 MG TABLET">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#167"/>
      </node>
      <node TEXT="TRULICITY 1.5 MG/0.5 ML PEN">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#365"/>
      </node>
      <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PEN">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#13214"/>
      </node>
      <node TEXT="XARELTO 10 MG TABLET">
        <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9718"/>
      </node>
    </node>
    <node TEXT="Comments Section">
      <node TEXT="Comment Form">
        <node TEXT="Input: What do you think?"/>
        <node TEXT="Button: Post"/>
      </node>
      <node TEXT="Comments List">
        <node TEXT="User questions and expert replies about 340B pricing, supply, coverage, and usage."/>
        <node TEXT="Button: Load more comments"/>
      </node>
    </node>
    <node TEXT="Assign Pharmacy Notice">
      <node TEXT="Please assign pharmacy from the portal first"/>
    </node>
    <node TEXT="Search Filters Form">
      <node TEXT="Select Pharmacy"/>
      <node TEXT="Select Patient Group"/>
      <node TEXT="Select Formulary"/>
      <node TEXT="Button: Clear All Data"/>
    </node>
  </node>
</map>