<map version="1.0.1">
  <node TEXT="Profile">
    <node TEXT="User Profile Overview">
      <node TEXT="Ali Zain (Online) - Profile summary and status"/>
    </node>
    <node TEXT="Details Section">
      <node TEXT="Username: Ali, First Name: Ali, Last Name: Zain, Clinic/Hospital: ABC"/>
      <node TEXT="Email Address">
        <node TEXT="alizainsharif48@gmail.com"/>
      </node>
    </node>
    <node TEXT="Edit Profile">
      <node TEXT="Edit Profile"/>
    </node>
  </node>
</map>