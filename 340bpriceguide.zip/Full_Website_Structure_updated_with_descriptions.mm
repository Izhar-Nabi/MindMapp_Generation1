<?xml version='1.0' encoding='UTF-8'?>
<map version="1.0.1">
  <node TEXT="Home Page" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Logo" LINK="https://www.340bpriceguide.net/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Navigation Links" FOLDED="true">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search" FOLDED="true">
          <node TEXT="Frequently Searched Products" FOLDED="true">
            <node TEXT="ADVAIR HFA 230-21 MCG INHALER" LINK="https://www.340bpriceguide.net/340b-search#486" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_486.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="BREO ELLIPTA 100-25 MCG INHALR" LINK="https://www.340bpriceguide.net/340b-search#488" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_488.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="BUTRANS 5 MCG/HR PATCH" LINK="https://www.340bpriceguide.net/340b-search#14857" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_14857.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="DULERA 200 MCG-5 MCG INHALER" LINK="https://www.340bpriceguide.net/340b-search#13331" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_13331.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="FARXIGA 10 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#116" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_116.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="JANUVIA 100 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#534" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_534.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="JARDIANCE 10 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#185" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_185.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="LANTUS SOLOSTAR 100 UNIT/ML" LINK="https://www.340bpriceguide.net/340b-search#588" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_588.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="LIDOCAINE 5% PATCH" LINK="https://www.340bpriceguide.net/340b-search#2310" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_2310.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="LYRICA 100 MG CAPSULE" LINK="https://www.340bpriceguide.net/340b-search#19309" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_19309.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="PROAIR RESPICLICK 90 MCG INHLR" LINK="https://www.340bpriceguide.net/340b-search#18373" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_18373.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="TRADJENTA 5 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#167" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_167.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="TRULICITY 1.5 MG/0.5 ML PEN" LINK="https://www.340bpriceguide.net/340b-search#365" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_365.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PEN" LINK="https://www.340bpriceguide.net/340b-search#13214" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_13214.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="XARELTO 10 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#9718" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search_9718.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Comments Section" FOLDED="true">
            <node TEXT="Users ask questions and share experiences about 340B pricing, pharmacy coverage, and medication availability." FOLDED="true"/>
            <node TEXT="Search Comments Form" FOLDED="true">
              <node TEXT="Search Comments Field" FOLDED="true"/>
              <node TEXT="Sort By Dropdown" FOLDED="true"/>
            </node>
            <node TEXT="Load more comments Button" FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news" FOLDED="true">
          <node TEXT="Weekly Product Shortages" FOLDED="true">
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Manufacturer 340B Restrictions for Oregon" FOLDED="true">
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_144-status-of-manufacturer-340b-restrictions-for-oregon.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026" FOLDED="true">
            <node TEXT="Novo Nordisk recently announced changes to the eligibility criteria for its Patient Assistance Program for 2026." FOLDED="true"/>
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_143-changes-to-novo-nordisk-patient-assistance-program-pap-2026.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Bausch Health Exits the 340B Drug Pricing Program" FOLDED="true">
            <node TEXT="Bausch Health ended participation in the 340B Drug Pricing Program as of October 1, 2025." FOLDED="true"/>
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_142-bausch-health-exits-the-340b-drug-pricing-program.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="More Articles" FOLDED="true">
            <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" LINK="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="Communication from BPHC announcing new award terms" LINK="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_140-communication-from-bphc-announcing-new-award-terms.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="Rite Aid Winds Down 340B Operations" LINK="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_139-rite-aid-winds-down-340b-operations.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="Continued Brand Name Victoza Shortages" LINK="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_138-continued-brand-name-victoza-shortages.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Pagination" FOLDED="true">
            <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_4.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_8.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_12.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_16.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_20.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_4.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=20" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_start_20.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us" FOLDED="true">
          <node TEXT="340B Price Guide Overview" FOLDED="true">
            <node TEXT="Customized publication for health organizations to interpret 340B drug prices and their impact." FOLDED="true"/>
          </node>
          <node TEXT="340B Guided Services" FOLDED="true">
            <node TEXT="Independent consulting and guidance for 340B program management and best practices." FOLDED="true"/>
            <node TEXT="Welcomes inquiries from all covered entities." FOLDED="true"/>
          </node>
          <node TEXT="Client Logos" FOLDED="true">
            <node TEXT="Visual display of partner and client health organizations." FOLDED="true"/>
          </node>
          <node TEXT="Client Testimonials" FOLDED="true">
            <node TEXT="Testimonials highlight cost savings, improved patient care, and ease of use for 340B Price Guide." FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_about-us.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us" FOLDED="true">
          <node TEXT="Contact Form" FOLDED="true">
            <node TEXT="Name Field" FOLDED="true"/>
            <node TEXT="Email Field" FOLDED="true"/>
            <node TEXT="Company Field" FOLDED="true"/>
            <node TEXT="Address Field" FOLDED="true"/>
            <node TEXT="City, State Zip Field" FOLDED="true"/>
            <node TEXT="Phone Field" FOLDED="true"/>
            <node TEXT="Inquiry Type Dropdown" FOLDED="true"/>
            <node TEXT="Comment or Question Field" FOLDED="true"/>
            <node TEXT="Captcha Field" FOLDED="true"/>
            <node TEXT="SUBMIT" LINK="https://www.340bpriceguide.net/contact-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_contact-us.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_contact-us.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Search Icon" FOLDED="true"/>
    </node>
    <node TEXT="Sign up / Sign in" LINK="https://www.340bpriceguide.net/client-login?view=registration" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_client-login_view_registration.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node><node TEXT="After Login Flow" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="After Login Flow" LINK="https://www.340bpriceguide.net/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search" FOLDED="true">
        <node TEXT="Frequently Searched Products" FOLDED="true">
          <node TEXT="ADVAIR HFA 230-21 MCG INHALER" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#486" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_486.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="BREO ELLIPTA 100-25 MCG INHALR" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#488" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_488.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="BUTRANS 5 MCG/HR PATCH" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#14857" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_14857.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="DULERA 200 MCG-5 MCG INHALER" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#13331" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_13331.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="FARXIGA 10 MG TABLET" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#116" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_116.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="JANUVIA 100 MG TABLET" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#534" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_534.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="JARDIANCE 10 MG TABLET" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#185" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_185.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="LANTUS SOLOSTAR 100 UNIT/ML" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#588" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_588.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="LIDOCAINE 5% PATCH" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#2310" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_2310.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="LYRICA 100 MG CAPSULE" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#19309" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_19309.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="PROAIR RESPICLICK 90 MCG INHLR" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#18373" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_18373.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="TRADJENTA 5 MG TABLET" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#167" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_167.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="TRULICITY 1.5 MG/0.5 ML PEN" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#365" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_365.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PEN" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#13214" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_13214.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="XARELTO 10 MG TABLET" FOLDED="true">
            <node TEXT="Link" LINK="https://www.340bpriceguide.net/340b-search#9718" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search_9718.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
        </node>
        <node TEXT="Comments Section" FOLDED="true">
          <node TEXT="Comment Form" FOLDED="true">
            <node TEXT="Input: What do you think?" FOLDED="true"/>
            <node TEXT="Button: Post" FOLDED="true"/>
          </node>
          <node TEXT="Comments List" FOLDED="true">
            <node TEXT="User questions and expert replies about 340B pricing, supply, coverage, and usage." FOLDED="true"/>
            <node TEXT="Button: Load more comments" FOLDED="true"/>
          </node>
        </node>
        <node TEXT="Assign Pharmacy Notice" FOLDED="true">
          <node TEXT="Please assign pharmacy from the portal first" FOLDED="true"/>
        </node>
        <node TEXT="Search Filters Form" FOLDED="true">
          <node TEXT="Select Pharmacy" FOLDED="true"/>
          <node TEXT="Select Patient Group" FOLDED="true"/>
          <node TEXT="Select Formulary" FOLDED="true"/>
          <node TEXT="Button: Clear All Data" FOLDED="true"/>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_340b-search.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news" FOLDED="true">
        <node TEXT="Featured Articles" FOLDED="true">
          <node TEXT="Weekly Product Shortages" FOLDED="true">
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Manufacturer 340B Restrictions for Oregon" FOLDED="true">
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_144-status-of-manufacturer-340b-restrictions-for-oregon.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026" FOLDED="true">
            <node TEXT="Novo Nordisk recently announced changes to the eligibility criteria for its Patient Assistance Program for 2026." FOLDED="true"/>
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_143-changes-to-novo-nordisk-patient-assistance-program-pap-2026.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Bausch Health Exits the 340B Drug Pricing Program" FOLDED="true">
            <node TEXT="Bausch Health ended its participation in the 340B Drug Pricing Program effective October 1, 2025." FOLDED="true"/>
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_142-bausch-health-exits-the-340b-drug-pricing-program.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
        </node>
        <node TEXT="More Articles" FOLDED="true">
          <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" FOLDED="true">
            <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September." LINK="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Communication from BPHC announcing new award terms" FOLDED="true">
            <node TEXT="Communication from BPHC announcing new award terms." LINK="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_140-communication-from-bphc-announcing-new-award-terms.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Rite Aid Winds Down 340B Operations" FOLDED="true">
            <node TEXT="Rite Aid Winds Down 340B Operations." LINK="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_139-rite-aid-winds-down-340b-operations.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Continued Brand Name Victoza Shortages" FOLDED="true">
            <node TEXT="Continued Brand Name Victoza Shortages." LINK="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_138-continued-brand-name-victoza-shortages.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          </node>
        </node>
        <node TEXT="Pagination" FOLDED="true">
          <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_4.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_8.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_12.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_16.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_20.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="7" LINK="https://www.340bpriceguide.net/articles-news?start=24" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_24.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_4.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
          <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=24" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_start_24.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us" FOLDED="true">
        <node TEXT="340B Price Guide Overview" FOLDED="true">
          <node TEXT="Summary: Customized publication for 340B drug discount program, helping entities interpret drug prices and patient care impact." FOLDED="true"/>
        </node>
        <node TEXT="340B Guided Services" FOLDED="true">
          <node TEXT="Summary: Consulting for covered entities on 340B program management and best practices, serving a range of health organizations." FOLDED="true"/>
        </node>
        <node TEXT="Client Testimonials" FOLDED="true">
          <node TEXT="Summary: Feedback from healthcare professionals highlighting the benefits and impact of the 340B Price Guide." FOLDED="true"/>
        </node>
        <node TEXT="Organizations Served" FOLDED="true">
          <node TEXT="Summary: Logos of various health organizations and clinics that have used 340B Price Guide services." FOLDED="true"/>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_about-us.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us" FOLDED="true">
        <node TEXT="Contact Form" FOLDED="true">
          <node TEXT="Name" FOLDED="true"/>
          <node TEXT="Email" FOLDED="true"/>
          <node TEXT="Company" FOLDED="true"/>
          <node TEXT="Address" FOLDED="true"/>
          <node TEXT="City, State Zip" FOLDED="true"/>
          <node TEXT="Phone" FOLDED="true"/>
          <node TEXT="Inquiry Type" FOLDED="true"/>
          <node TEXT="Comment or Question" FOLDED="true"/>
          <node TEXT="Captcha" FOLDED="true"/>
          <node TEXT="Submit Button" FOLDED="true"/>
        </node>
        <node TEXT="Contact Information Summary" FOLDED="true">
          <node TEXT="Address, phone, and email for 340B Price Guide" FOLDED="true"/>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_contact-us.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Profile" LINK="https://www.340bpriceguide.net/my-profile" FOLDED="true">
        <node TEXT="User Profile Overview" FOLDED="true">
          <node TEXT="Ali Zain (Online) - Profile summary and status" FOLDED="true"/>
        </node>
        <node TEXT="Details Section" FOLDED="true">
          <node TEXT="Username: Ali, First Name: Ali, Last Name: Zain, Clinic/Hospital: ABC" FOLDED="true"/>
          <node TEXT="Email Address" FOLDED="true">
            <node TEXT="alizainsharif48@gmail.com" FOLDED="true"/>
          </node>
        </node>
        <node TEXT="Edit Profile" FOLDED="true">
          <node TEXT="Edit Profile" FOLDED="true"/>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_my-profile.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="Logout" LINK="https://www.340bpriceguide.net/logout" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_logout.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
      <node TEXT="SecureMsg" LINK="https://www.340bpriceguide.net/secure-message" FOLDED="true">
        <node TEXT="Send Secure Message Form" FOLDED="true">
          <node TEXT="Patient Name" FOLDED="true"/>
          <node TEXT="Patient DOB" FOLDED="true"/>
          <node TEXT="Pharmacy" FOLDED="true"/>
          <node TEXT="Medication and Strength" FOLDED="true"/>
          <node TEXT="Prescription Number (if available)" FOLDED="true"/>
          <node TEXT="Contact at the pharmacy (if available)" FOLDED="true"/>
          <node TEXT="Problem/Comment" FOLDED="true"/>
          <node TEXT="SUBMIT Button" FOLDED="true"/>
        </node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_secure-message.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Main Content" FOLDED="true">
      <node TEXT="Image Carousel" FOLDED="true">
        <node TEXT="Community Health Centers Of Lane County" FOLDED="true"/>
        <node TEXT="Eugene, Oregon" FOLDED="true"/>
      </node>
      <node TEXT="What is 340B?" FOLDED="true">
        <node TEXT="Description: For the past 25 years, 340B has helped provide low-cost medications and better health..." FOLDED="true"/>
        <node TEXT="Learn More" LINK="https://www.340bpriceguide.net/articles-news/50-what-is-340b" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_50-what-is-340b.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Weekly Product Shortages" FOLDED="true">
        <node TEXT="Weekly Product Shortages" LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Useful Links" FOLDED="true">
        <node TEXT="After Login Flow" LINK="https://www.340bpriceguide.net/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_about-us.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_articles-news.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.340bpriceguide.net_index.php_contact-us.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Information" FOLDED="true">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us" FOLDED="true">
        <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" FOLDED="true"/>
        <node TEXT="Address: 501 Fourth Street, #854, Lake Oswego, OR 97034" FOLDED="true"/>
        <node TEXT="Phone: (503)298-0681" FOLDED="true"/>
      </node>
      <node TEXT="External Resources" FOLDED="true">
        <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
      <body>
        <p>
        <img src="hyperlink_screenshots_After_Login/http_www.hrsa.gov_opa.png" width="950" height="500"/>
        </p>
      </body>
    </html></richcontent></node></node>
      </node>
    </node>
  </node>
</node>
    <node TEXT="Main Content" FOLDED="true">
      <node TEXT="Hero Section" FOLDED="true">
        <node TEXT="Image Carousel" FOLDED="true"/>
        <node TEXT="Medication Search Form" FOLDED="true">
          <node TEXT="Enter a medication (input field)" FOLDED="true"/>
          <node TEXT="Find 340B Prices (button)" LINK="https://www.340bpriceguide.net/340b-search" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_340b-search.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        </node>
        <node TEXT="Featured Organization: Adelante Health Centers of Lane County, Phoenix, Arizona" FOLDED="true"/>
      </node>
      <node TEXT="What is 340B?" FOLDED="true">
        <node TEXT="For the past 25 years, 340B has helped provide low-cost medications and better health..." FOLDED="true"/>
        <node TEXT="Learn More" LINK="https://www.340bpriceguide.net/articles-news/50-what-is-340b" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_50-what-is-340b.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Weekly Product Shortages" FOLDED="true">
        <node TEXT="Current updates on medication shortages" FOLDED="true"/>
        <node TEXT="View Weekly Product Shortages" LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_articles-news_126-weekly-product-shortages.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Useful Links" FOLDED="true">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_about-us.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_articles-news.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.340bpriceguide.net_index.php_contact-us.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Information" FOLDED="true">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_torey-c-lam-387a162a.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Contact Us" FOLDED="true">
        <node TEXT="501 Fourth Street, #854, Lake Oswego, OR 97034" FOLDED="true"/>
        <node TEXT="Phone: (503)298-0681" FOLDED="true"/>
        <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" FOLDED="true"/>
      </node>
      <node TEXT="HRSA OPA Information" FOLDED="true">
        <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/http_www.hrsa.gov_opa.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Disclaimer" FOLDED="true">
        <node TEXT="340B Drug Pricing Program is managed by HRSA OPA. All prices are estimates and subject to change." FOLDED="true"/>
      </node>
    </node>
  </node>
</map>
