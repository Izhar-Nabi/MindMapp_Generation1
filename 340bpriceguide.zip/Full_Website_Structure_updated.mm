<map version="1.0.1">
  <node TEXT="Home Page">
    <node TEXT="Header">
      <node TEXT="Logo" LINK="https://www.340bpriceguide.net/" />
      <node TEXT="Navigation Links">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/" />
        <node TEXT="Search" LINK="https://www.340bpriceguide.net/340b-search">
          <node TEXT="Frequently Searched Products">
            <node TEXT="ADVAIR HFA 230-21 MCG INHALER" LINK="https://www.340bpriceguide.net/340b-search#486" />
            <node TEXT="BREO ELLIPTA 100-25 MCG INHALR" LINK="https://www.340bpriceguide.net/340b-search#488" />
            <node TEXT="BUTRANS 5 MCG/HR PATCH" LINK="https://www.340bpriceguide.net/340b-search#14857" />
            <node TEXT="DULERA 200 MCG-5 MCG INHALER" LINK="https://www.340bpriceguide.net/340b-search#13331" />
            <node TEXT="FARXIGA 10 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#116" />
            <node TEXT="JANUVIA 100 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#534" />
            <node TEXT="JARDIANCE 10 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#185" />
            <node TEXT="LANTUS SOLOSTAR 100 UNIT/ML" LINK="https://www.340bpriceguide.net/340b-search#588" />
            <node TEXT="LIDOCAINE 5% PATCH" LINK="https://www.340bpriceguide.net/340b-search#2310" />
            <node TEXT="LYRICA 100 MG CAPSULE" LINK="https://www.340bpriceguide.net/340b-search#19309" />
            <node TEXT="PROAIR RESPICLICK 90 MCG INHLR" LINK="https://www.340bpriceguide.net/340b-search#18373" />
            <node TEXT="TRADJENTA 5 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#167" />
            <node TEXT="TRULICITY 1.5 MG/0.5 ML PEN" LINK="https://www.340bpriceguide.net/340b-search#365" />
            <node TEXT="VICTOZA 2-PAK 18 MG/3 ML PEN" LINK="https://www.340bpriceguide.net/340b-search#13214" />
            <node TEXT="XARELTO 10 MG TABLET" LINK="https://www.340bpriceguide.net/340b-search#9718" />
          </node>
          <node TEXT="Comments Section">
            <node TEXT="Users ask questions and share experiences about 340B pricing, pharmacy coverage, and medication availability." />
            <node TEXT="Search Comments Form">
              <node TEXT="Search Comments Field" />
              <node TEXT="Sort By Dropdown" />
            </node>
            <node TEXT="Load more comments Button" />
          </node>
        </node>
        <node TEXT="Articles" LINK="https://www.340bpriceguide.net/articles-news">
          <node TEXT="Weekly Product Shortages">
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" />
          </node>
          <node TEXT="Manufacturer 340B Restrictions for Oregon">
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/144-status-of-manufacturer-340b-restrictions-for-oregon" />
          </node>
          <node TEXT="Novo Nordisk Changes Patient Assistance Program (PAP) 2026">
            <node TEXT="Novo Nordisk recently announced changes to the eligibility criteria for its Patient Assistance Program for 2026." />
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/143-changes-to-novo-nordisk-patient-assistance-program-pap-2026" />
          </node>
          <node TEXT="Bausch Health Exits the 340B Drug Pricing Program">
            <node TEXT="Bausch Health ended participation in the 340B Drug Pricing Program as of October 1, 2025." />
            <node TEXT="Read more ..." LINK="https://www.340bpriceguide.net/articles-news/142-bausch-health-exits-the-340b-drug-pricing-program" />
          </node>
          <node TEXT="More Articles">
            <node TEXT="The FreeStyle Libre 2 and FreeStyle Libre 3 sensors will be discontinued in September" LINK="https://www.340bpriceguide.net/articles-news/141-the-freestyle-libre-2-and-freestyle-libre-3-sensors-will-be-discontinued-in-september" />
            <node TEXT="Communication from BPHC announcing new award terms" LINK="https://www.340bpriceguide.net/articles-news/140-communication-from-bphc-announcing-new-award-terms" />
            <node TEXT="Rite Aid Winds Down 340B Operations" LINK="https://www.340bpriceguide.net/articles-news/139-rite-aid-winds-down-340b-operations" />
            <node TEXT="Continued Brand Name Victoza Shortages" LINK="https://www.340bpriceguide.net/articles-news/138-continued-brand-name-victoza-shortages" />
          </node>
          <node TEXT="Pagination">
            <node TEXT="2" LINK="https://www.340bpriceguide.net/articles-news?start=4" />
            <node TEXT="3" LINK="https://www.340bpriceguide.net/articles-news?start=8" />
            <node TEXT="4" LINK="https://www.340bpriceguide.net/articles-news?start=12" />
            <node TEXT="5" LINK="https://www.340bpriceguide.net/articles-news?start=16" />
            <node TEXT="6" LINK="https://www.340bpriceguide.net/articles-news?start=20" />
            <node TEXT="Next" LINK="https://www.340bpriceguide.net/articles-news?start=4" />
            <node TEXT="End" LINK="https://www.340bpriceguide.net/articles-news?start=20" />
          </node>
        </node>
        <node TEXT="About" LINK="https://www.340bpriceguide.net/about-us">
          <node TEXT="340B Price Guide Overview">
            <node TEXT="Customized publication for health organizations to interpret 340B drug prices and their impact." />
          </node>
          <node TEXT="340B Guided Services">
            <node TEXT="Independent consulting and guidance for 340B program management and best practices." />
            <node TEXT="Welcomes inquiries from all covered entities." />
          </node>
          <node TEXT="Client Logos">
            <node TEXT="Visual display of partner and client health organizations." />
          </node>
          <node TEXT="Client Testimonials">
            <node TEXT="Testimonials highlight cost savings, improved patient care, and ease of use for 340B Price Guide." />
          </node>
        </node>
        <node TEXT="Contact" LINK="https://www.340bpriceguide.net/contact-us">
          <node TEXT="Contact Form">
            <node TEXT="Name Field" />
            <node TEXT="Email Field" />
            <node TEXT="Company Field" />
            <node TEXT="Address Field" />
            <node TEXT="City, State Zip Field" />
            <node TEXT="Phone Field" />
            <node TEXT="Inquiry Type Dropdown" />
            <node TEXT="Comment or Question Field" />
            <node TEXT="Captcha Field" />
            <node TEXT="SUBMIT" LINK="https://www.340bpriceguide.net/contact-us" />
          </node>
        </node>
      </node>
      <node TEXT="Search Icon" />
    </node>
    <node TEXT="Sign up / Sign in" LINK="https://www.340bpriceguide.net/client-login?view=registration" />
    <node TEXT="Main Content">
      <node TEXT="Hero Section">
        <node TEXT="Image Carousel" />
        <node TEXT="Medication Search Form">
          <node TEXT="Enter a medication (input field)" />
          <node TEXT="Find 340B Prices (button)" LINK="https://www.340bpriceguide.net/340b-search" />
        </node>
        <node TEXT="Featured Organization: Adelante Health Centers of Lane County, Phoenix, Arizona" />
      </node>
      <node TEXT="What is 340B?">
        <node TEXT="For the past 25 years, 340B has helped provide low-cost medications and better health..." />
        <node TEXT="Learn More" LINK="https://www.340bpriceguide.net/articles-news/50-what-is-340b" />
      </node>
      <node TEXT="Weekly Product Shortages">
        <node TEXT="Current updates on medication shortages" />
        <node TEXT="View Weekly Product Shortages" LINK="https://www.340bpriceguide.net/articles-news/126-weekly-product-shortages" />
      </node>
    </node>
    <node TEXT="Footer">
      <node TEXT="Useful Links">
        <node TEXT="Home" LINK="https://www.340bpriceguide.net/" />
        <node TEXT="About Us" LINK="https://www.340bpriceguide.net/index.php/about-us" />
        <node TEXT="Articles &amp; News" LINK="https://www.340bpriceguide.net/index.php/articles-news" />
        <node TEXT="Contact Us" LINK="https://www.340bpriceguide.net/index.php/contact-us" />
      </node>
      <node TEXT="Information">
        <node TEXT="Linkedin" LINK="https://www.linkedin.com/in/torey-c-lam-387a162a" />
      </node>
      <node TEXT="Contact Us">
        <node TEXT="501 Fourth Street, #854, Lake Oswego, OR 97034" />
        <node TEXT="Phone: (503)298-0681" />
        <node TEXT="Email: info@340Bpriceguide.net" LINK="mailto:info@340Bpriceguide.com" />
      </node>
      <node TEXT="HRSA OPA Information">
        <node TEXT="www.hrsa.gov/opa" LINK="http://www.hrsa.gov/opa" />
      </node>
      <node TEXT="Disclaimer">
        <node TEXT="340B Drug Pricing Program is managed by HRSA OPA. All prices are estimates and subject to change." />
      </node>
    </node>
  </node>
</map>