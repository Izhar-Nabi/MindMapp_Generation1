<?xml version='1.0' encoding='UTF-8'?>
<map version="freeplane 1.11.12">
  <node TEXT="Home Page" ID="ID_HOME" FOLDED="true">
    <node TEXT="Header" ID="ID_HEADER" FOLDED="true">
      <node TEXT="About" ID="ID_ABOUT" LINK="https://www.example.com/about" FOLDED="true">
        <node TEXT="Button: Learn More" ID="ID_ABOUT_BTN1" FOLDED="true"/>
        <node TEXT="Link: Team" ID="ID_ABOUT_LINK1" LINK="https://www.example.com/about/team" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_about_team.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_about.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Contact" ID="ID_CONTACT" LINK="https://www.example.com/contact" FOLDED="true">
        <node TEXT="Form: Contact Form" ID="ID_CONTACT_FORM1" FOLDED="true"/>
        <node TEXT="Button: Submit" ID="ID_CONTACT_BTN1" FOLDED="true"/>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_contact.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Search" ID="ID_SEARCH" LINK="https://www.example.com/search" FOLDED="true">
        <node TEXT="Form: Search Box" ID="ID_SEARCH_FORM1" FOLDED="true"/>
        <node TEXT="Button: Search" ID="ID_SEARCH_BTN1" FOLDED="true"/>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_search.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Login" ID="ID_LOGIN" LINK="https://www.example.com/login" FOLDED="true">
        <node TEXT="Form: Login Form" ID="ID_LOGIN_FORM1" FOLDED="true"/>
        <node TEXT="Button: Log In" ID="ID_LOGIN_BTN1" FOLDED="true"/>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_login.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Signup" ID="ID_SIGNUP" LINK="https://www.example.com/signup" FOLDED="true">
        <node TEXT="Form: Signup Form" ID="ID_SIGNUP_FORM1" FOLDED="true"/>
        <node TEXT="Button: Sign Up" ID="ID_SIGNUP_BTN1" FOLDED="true"/>
      <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_signup.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Main Content" ID="ID_MAIN_CONTENT" FOLDED="true">
      <node TEXT="Welcome Banner" ID="ID_BANNER" FOLDED="true"/>
      <node TEXT="Featured Articles" ID="ID_FEATURED_ARTICLES" FOLDED="true"/>
    </node>
    <node TEXT="Footer" ID="ID_FOOTER" FOLDED="true">
      <node TEXT="Link: Privacy Policy" ID="ID_FOOTER_LINK1" LINK="https://www.example.com/privacy" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_privacy.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Link: Terms of Service" ID="ID_FOOTER_LINK2" LINK="https://www.example.com/terms" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_terms.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
  </node>
</map>
