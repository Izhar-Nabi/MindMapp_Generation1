<node TEXT="contact us">
    <node TEXT="Main Content">
      <node TEXT="Contact Information">
        <node TEXT="Our Office">
          <node TEXT="DayZee Field Office, Hasil Pur Road, Ada Sabeel, Bahawalpur." LINK="https://maps.app.goo.gl/WstmNjesSmVKyyB66"/>
        </node>
        <node TEXT="Call Us">
          <node TEXT="0331-443 1111" LINK="tel:0331 443 1111"/>
          <node TEXT="0331-447 6666" LINK="tel:0331 447 66 66"/>
        </node>
        <node TEXT="Email Address">
          <node TEXT="info@dayzee.com" LINK="mailto:info@dayzee.com"/>
        </node>
      </node>
      <node TEXT="Get in touch Let’s Get Started">
        <node TEXT="Contact Form">
          <node TEXT="First Name Field"/>
          <node TEXT="Last Name Field"/>
          <node TEXT="Email Field"/>
          <node TEXT="Mobile Number Field"/>
          <node TEXT="Company Name Field"/>
          <node TEXT="Country Field"/>
          <node TEXT="Interested In Field"/>
          <node TEXT="Message Field"/>
          <node TEXT="SUBMIT"/>
        </node>
      </node>
    </node>
  </node>