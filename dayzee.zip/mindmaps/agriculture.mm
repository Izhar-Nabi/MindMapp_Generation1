<node TEXT="agriculture">
    <node TEXT="Agriculture – Dayzee">
      <node TEXT="Main Content">
        <node TEXT="Hero Section">
          <node TEXT="Transforming 4,200 barren acres into a sustainable livestock and agricultural hub."/>
        </node>
        <node TEXT="A New Era of Desert Farming">
          <node TEXT="DayZee is turning barren land into a thriving agricultural center with innovative solutions."/>
        </node>
        <node TEXT="Barren Land">
          <node TEXT="Showcasing transformation of desert land for agriculture."/>
        </node>
        <node TEXT="Technology In Agriculture">
          <node TEXT="Highlighting the role of technology in modern agriculture."/>
        </node>
        <node TEXT="Our Products">
          <node TEXT="Section introducing available agricultural products."/>
        </node>
        <node TEXT="Our Services">
          <node TEXT="Land Development">
            <node TEXT="Transforming barren land into productive farms with tailored solutions."/>
          </node>
          <node TEXT="Center Pivot Irrigation Systems">
            <node TEXT="Providing efficient irrigation solutions for sustainable agriculture."/>
          </node>
          <node TEXT="Farm Operations">
            <node TEXT="Managing daily farm activities to ensure productivity and quality."/>
          </node>
          <node TEXT="Integrated Farm Management">
            <node TEXT="Offering expertise in planning, control, and monitoring of farm operations."/>
          </node>
          <node TEXT="Irrigation &amp; Infrastructure Consultancy">
            <node TEXT="Advising on irrigation and infrastructure for optimal farm performance."/>
          </node>
        </node>
        <node TEXT="Our Global Partners">
          <node TEXT="Partners include leaders in agriculture and farming innovation."/>
        </node>
        <node TEXT="Get in touch – Let’s Get Started">
          <node TEXT="Contact Form">
            <node TEXT="First Name Field"/>
            <node TEXT="Last Name Field"/>
            <node TEXT="Email Field"/>
            <node TEXT="Mobile Number Field"/>
            <node TEXT="Message For Field"/>
            <node TEXT="Country Field"/>
            <node TEXT="Message Field"/>
            <node TEXT="SUBMIT" LINK="https://dayzee.com/contact-us/"/>
          </node>
        </node>
      </node>
    </node>
  </node>