<?xml version='1.0' encoding='utf-8'?>
<map version="0.9.0">
  <node TEXT="Dayzee">
    <node TEXT="Header">
      <node TEXT="Navigation Links">
        <node TEXT="About Us" LINK="https://dayzee.com/about/" />
        <node TEXT="Livestock" LINK="https://dayzee.com/live-stock/" />
        <node TEXT="Agriculture" LINK="https://dayzee.com/agriculture/" />
        <node TEXT="Renewable Energy" LINK="https://dayzee.com/renewable-energy/" />
        <node TEXT="Gallery" LINK="https://dayzee.com/gallery/" />
        <node TEXT="Contact Us" LINK="https://dayzee.com/contact-us/" />
      </node>
    </node>
    <node TEXT="Main Content">
      <node TEXT="Embryo   Semen Production Units" />
      <node TEXT="Revolutionizing Livestock Genetics" />
    </node>
    <node TEXT="Footer">
      <node TEXT="Social Media">
        <node TEXT="Facebook" LINK="https://www.facebook.com/dayzeepvtltd" />
        <node TEXT="Tik Tok" LINK="https://www.tiktok.com/@dayzee.pvt.ltd" />
        <node TEXT="Instagram" LINK="https://www.instagram.com/dayzee_pvt_ltd/" />
        <node TEXT="Youtube" LINK="https://www.youtube.com/@DayZee_Pvt_Ltd" />
      </node>
      <node TEXT="FAQs" LINK="https://dayzee.com/faqs" />
    </node>
  </node>
</map>