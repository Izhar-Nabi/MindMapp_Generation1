<node TEXT="renewable energy">
    <node TEXT="Renewable Energy – Dayzee">
      <node TEXT="Main Content">
        <node TEXT="Hero Section">
          <node TEXT="Reducing Carbon Emissions Today – Building A 100% Clean Energy Future"/>
        </node>
        <node TEXT="Solar Panel Infrastructure">
          <node TEXT="6MW solar panels provide clean, efficient, and cost-effective energy for farm operations and reduce carbon emissions."/>
        </node>
        <node TEXT="Our Biogas Plant">
          <node TEXT="Biogas plant converts organic farm waste into renewable energy, reducing methane emissions and supporting a circular economy."/>
        </node>
        <node TEXT="The Precision Agriculture">
          <node TEXT="Precision agriculture enables efficient, data-driven farming for improved productivity and sustainability."/>
          <node TEXT="000 Delivered Packages"/>
          <node TEXT="000 Global Shipping"/>
          <node TEXT="000 Air Freight"/>
          <node TEXT="000 Happy Customers"/>
        </node>
        <node TEXT="Corporate Social Responsibility (CSR)">
          <node TEXT="Empowering Rural Communities">
            <node TEXT="Over 150 jobs created, providing sustainable livelihoods and uplifting local families."/>
          </node>
          <node TEXT="Farmer Development">
            <node TEXT="Awareness sessions on modern farming, IVF, and animal husbandry for smallholders."/>
          </node>
          <node TEXT="Environmental Stewardship">
            <node TEXT="Solar and biogas projects reduce emissions, making DayZee a model for sustainable agribusiness."/>
          </node>
          <node TEXT="Animal Ethics &amp; Welfare">
            <node TEXT="High welfare standards with a focus on nutrition, care, and ethical reproduction practices."/>
          </node>
        </node>
        <node TEXT="Get in touch – Let’s Get Started">
          <node TEXT="Contact Form">
            <node TEXT="First Name Field"/>
            <node TEXT="Last Name Field"/>
            <node TEXT="Email Field"/>
            <node TEXT="Mobile Number Field"/>
            <node TEXT="Company Name Field"/>
            <node TEXT="City Field"/>
            <node TEXT="Country Field"/>
            <node TEXT="Interested In Field"/>
            <node TEXT="Message Field"/>
            <node TEXT="Submit" LINK="https://dayzee.com/contact-us/"/>
          </node>
          <node TEXT="Connect with DayZee for expert farming and livestock solutions. We’re just a message away."/>
        </node>
      </node>
    </node>
  </node>