<node TEXT="livestock">
    <node TEXT="Live Stock – Dayzee">
      <node TEXT="Main Content">
        <node TEXT="Hero Section">
          <node TEXT="Superior genetics for tomorrow: Imported Brahman, Beefmaster, Slick Friesians &amp; Red Angus for superior performance in Pakistan."/>
          <node TEXT="REQUEST SEMEN/EMBRYO" LINK="tel:+923314476666"/>
          <node TEXT="BOOK A CONSULTATION" LINK="tel:+923314431111"/>
          <node TEXT="BOOK OPU OF YOUR COW NOW" LINK="tel:+923314431111"/>
        </node>
        <node TEXT="About Our Genetics">
          <node TEXT="Slick Gene Friesian: Imported Friesian with special heat-resistant gene for high milk yield and resilience."/>
          <node TEXT="Brahman: Imported pure line, known for beef and ruggedness."/>
          <node TEXT="Beefmaster: Fertility, rapid weight gain, and carcass quality for premium beef production."/>
          <node TEXT="Red Angus: Delivers high fertility, easy calving, and marbling for premium beef."/>
        </node>
        <node TEXT="Our Services">
          <node TEXT="Semen Availability: Semen from high-performing, international bulls for herd improvement."/>
          <node TEXT="Embryo Transfer Pregnancies: Elite genetics via embryo transfer for rapid herd progress."/>
          <node TEXT="Pregnant Heifers for Sale: Pregnant heifers, sourced and bred for productivity and health."/>
          <node TEXT="Genetics Consultation: Expert advice to help you choose the right genetics for your goals."/>
        </node>
        <node TEXT="Want 20+ calves from one elite donor cow?">
          <node TEXT="With Ovum Pick-up (OPU) and IVF, multiply your top genetics at scale."/>
          <node TEXT="Book OPU Now" LINK="tel:+92314431111"/>
        </node>
        <node TEXT="Explore Our Genetic Catalogue">
          <node TEXT="Brahman Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/American-Brahmans.pdf"/>
          <node TEXT="Slick-Gene Friesian Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/Slick-Gene.pdf"/>
          <node TEXT="Beefmaster Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/Beef-Master.pdf"/>
          <node TEXT="Red Angus Catalogue" LINK="https://dayzee.com/wp-content/uploads/2025/09/Red-Angus.pdf"/>
        </node>
        <node TEXT="Our Global Partners">
          <node TEXT="Our genetics are backed by world leaders in livestock science and breeding."/>
        </node>
        <node TEXT="Get in touch – Let’s Get Started">
          <node TEXT="Contact Form">
            <node TEXT="First Name Field"/>
            <node TEXT="Last Name Field"/>
            <node TEXT="Company Name Field"/>
            <node TEXT="Contact Number Field"/>
            <node TEXT="Country Field"/>
            <node TEXT="Interested In Field"/>
            <node TEXT="Message Field"/>
            <node TEXT="SUBMIT"/>
          </node>
        </node>
      </node>
    </node>
  </node>