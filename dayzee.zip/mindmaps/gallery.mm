<node TEXT="gallery">
    <node TEXT="Main Content">
      <node TEXT="Image Gallery">
        <node TEXT="Photo section showcasing DayZee events and livestock activities."/>
      </node>
      <node TEXT="Get in touch">
        <node TEXT="Connect with DayZee for expert farming and livestock solutions. We're just a message away."/>
        <node TEXT="Contact Form">
          <node TEXT="First Name Field"/>
          <node TEXT="Last Name Field"/>
          <node TEXT="Email Field"/>
          <node TEXT="Mobile Number Field"/>
          <node TEXT="Company Name Field"/>
          <node TEXT="Country Field"/>
          <node TEXT="Interested In Field"/>
          <node TEXT="Message Field"/>
          <node TEXT="SUBMIT"/>
        </node>
      </node>
      <node TEXT="About DayZee">
        <node TEXT="DayZee specializes in advanced agriculture, livestock genetics, and sustainable farming solutions."/>
      </node>
    </node>
  </node>