<node TEXT="about us">
    <node TEXT="Main Content">
      <node TEXT="DayZee Farms Began with a Bold Idea">
        <node TEXT="DayZee Farms aims to transform farming in Pakistan through global expertise and local passion."/>
        <node TEXT="We launched DayZee Livestock">
          <node TEXT="Progressive dairy and beef genetics introduced for local farmers."/>
        </node>
        <node TEXT="DayZee Agriculture">
          <node TEXT="Modern irrigation and premium animal fodder for smarter, more efficient farming."/>
        </node>
        <node TEXT="Solar Installation">
          <node TEXT="6MW solar installation powers operations with renewable energy."/>
        </node>
        <node TEXT="Intersection of science and soil">
          <node TEXT="Combining science and local expertise for world-class agricultural solutions."/>
        </node>
      </node>
      <node TEXT="Our Impact on the UN Sustainable Development Goals (SDGs)">
        <node TEXT="SDG 2 – Zero Hunger">
          <node TEXT="Improved livestock productivity and crop yields for a stronger food supply chain."/>
        </node>
        <node TEXT="SDG 7 – Affordable and Clean Energy">
          <node TEXT="Solar and biogas plants demonstrate affordable, sustainable energy for agriculture."/>
        </node>
        <node TEXT="SDG 9 – Industry, Innovation and Infrastructure">
          <node TEXT="IVF lab, modern irrigation, and genetics drive agricultural innovation."/>
        </node>
        <node TEXT="SDG 12 – Responsible Consumption and Production">
          <node TEXT="Promoting sustainable resource use and reducing carbon footprint in livestock."/>
        </node>
        <node TEXT="SDG 13 – Climate Action">
          <node TEXT="Heat-tolerant breeds and renewable energy support climate-resilient farming."/>
        </node>
      </node>
      <node TEXT="Get in touch – Let's Get Started">
        <node TEXT="Contact Form">
          <node TEXT="Name Field"/>
          <node TEXT="Email Field"/>
          <node TEXT="Mobile Number Field"/>
          <node TEXT="Company Name Field"/>
          <node TEXT="City Field"/>
          <node TEXT="Country Field"/>
          <node TEXT="Interested In Field"/>
          <node TEXT="Message Field"/>
          <node TEXT="SUBMIT"/>
        </node>
        <node TEXT="Connect with DayZee for expert farming and livestock solutions."/>
      </node>
    </node>
  </node>