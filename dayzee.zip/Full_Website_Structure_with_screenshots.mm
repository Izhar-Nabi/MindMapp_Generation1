<?xml version='1.0' encoding='utf-8'?>
<map version="freeplane 1.11.12">
  <node TEXT="Home Page" ID="ID_HOME">
    <node TEXT="Header" ID="ID_HEADER">
      <node TEXT="About" ID="ID_ABOUT" LINK="https://www.example.com/about">
        <node TEXT="Button: Learn More" ID="ID_ABOUT_BTN1" />
        <node TEXT="Link: Team" ID="ID_ABOUT_LINK1" LINK="https://www.example.com/about/team"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_about_team.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_about.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Contact" ID="ID_CONTACT" LINK="https://www.example.com/contact">
        <node TEXT="Form: Contact Form" ID="ID_CONTACT_FORM1" />
        <node TEXT="Button: Submit" ID="ID_CONTACT_BTN1" />
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_contact.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Search" ID="ID_SEARCH" LINK="https://www.example.com/search">
        <node TEXT="Form: Search Box" ID="ID_SEARCH_FORM1" />
        <node TEXT="Button: Search" ID="ID_SEARCH_BTN1" />
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_search.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Login" ID="ID_LOGIN" LINK="https://www.example.com/login">
        <node TEXT="Form: Login Form" ID="ID_LOGIN_FORM1" />
        <node TEXT="Button: Log In" ID="ID_LOGIN_BTN1" />
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_login.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Signup" ID="ID_SIGNUP" LINK="https://www.example.com/signup">
        <node TEXT="Form: Signup Form" ID="ID_SIGNUP_FORM1" />
        <node TEXT="Button: Sign Up" ID="ID_SIGNUP_BTN1" />
      <node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_signup.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Main Content" ID="ID_MAIN_CONTENT">
      <node TEXT="Welcome Banner" ID="ID_BANNER" />
      <node TEXT="Featured Articles" ID="ID_FEATURED_ARTICLES" />
    </node>
    <node TEXT="Footer" ID="ID_FOOTER">
      <node TEXT="Link: Privacy Policy" ID="ID_FOOTER_LINK1" LINK="https://www.example.com/privacy"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_privacy.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Link: Terms of Service" ID="ID_FOOTER_LINK2" LINK="https://www.example.com/terms"><node TEXT="Screenshot Example"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.example.com_terms.png" width="950" height="500" />
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
  </node>
</map>