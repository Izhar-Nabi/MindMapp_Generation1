<?xml version='1.0' encoding='utf-8'?>
<map version="freeplane 1.11.12">
  <node TEXT="home" ID="ID_HOME">
    <node TEXT="Header" ID="ID_HEADER" />
  </node>
</map>