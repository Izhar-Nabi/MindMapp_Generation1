<map version="0.9.0">
  <node TEXT="Home Page">
    <node TEXT="Header">
      <node TEXT="Navigation Links">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/">
          <node TEXT="The Power of &amp;">
            <node TEXT="Fostering the power of and, these founders built a model of work where work &amp; life could be in harmony." />
          </node>
          <node TEXT="Re-imagining Work &amp; Life">
            <node TEXT="How it all started: Building a new approach to work and life integration." />
            <node TEXT="Key Beliefs">
              <node TEXT="It is time to reimagine a thriving, equitable, and engaged community of work and life." />
              <node TEXT="We must build different &amp; better." />
              <node TEXT="We must balance demands, mental nourishment, and impact." />
              <node TEXT="To keep adapting AND create the power of &amp;." />
            </node>
          </node>
          <node TEXT="Vision &amp; Mission">
            <node TEXT="Vision: To unlock the full potential of the workforce." />
            <node TEXT="Mission: We strengthen businesses with the power of the independent workforce and diverse teams." />
          </node>
          <node TEXT="Our Values">
            <node TEXT="These values stem from our focus on power, equity, and action, fueling how we work." />
            <node TEXT="Community: We nurture a community that lifts one another up and prioritizes common access &amp; representation." />
            <node TEXT="Impact: We seek the highest &amp; best ways, measuring success in outcomes not outputs." />
            <node TEXT="Stewardship: We serve plus advocate, leaving all we touch better than we found them." />
            <node TEXT="Courage: We lead with determination and resilience, pushing the boundaries of what is possible." />
          </node>
          <node TEXT="Recent Recognition">
            <node TEXT="Awards and recognitions for impact and innovation." />
          </node>
          <node TEXT="L&amp;T Talent Network">
            <node TEXT="A diverse network of professionals supporting the mission." />
          </node>
          <node TEXT="Staff Team">
            <node TEXT="Brea Starmer, Founder, CEO">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/breastarmer" />
            </node>
            <node TEXT="Ashley Jude, President">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/ashleyjude" />
            </node>
            <node TEXT="Lorraine Cunningham, Chief Technology &amp; Financial Officer">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/cunninghamlorraine" />
            </node>
            <node TEXT="LaShunte Portrey, Business Development">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/lashunteportrey/" />
            </node>
            <node TEXT="Steven Rowe, Client Experience">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/sttrowe" />
            </node>
            <node TEXT="Reiko Kono, Client Experience Team">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/reiko-kono-161056171/" />
            </node>
            <node TEXT="Shannon Lee, Marketing">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/shannon-lee13/" />
            </node>
            <node TEXT="Nan Jackson, Client Experience">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/nanbjackson" />
            </node>
            <node TEXT="Miranda Leurquin, Talent Advocacy">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mirandaleurquin/" />
            </node>
            <node TEXT="Jocylynn Kelley, Talent Advocacy">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/jocylynn-kelley/" />
            </node>
            <node TEXT="Allison Monat, Talent Advocacy">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/allisonsmonat" />
            </node>
            <node TEXT="Mercedes Dunn, Talent Advocacy">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mercedesdunn/" />
            </node>
          </node>
          <node TEXT="Clients &amp; Talent Actions">
            <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/">
              <node TEXT="Main Content">
                <node TEXT="Intro">
                  <node TEXT="Interested in hiring our consultants? Complete this form and we’ll be in touch shortly." />
                  <node TEXT="Interested in joining our team of consultants? Learn more here." LINK="https://lionsandtigers.com/join-our-team" />
                </node>
                <node TEXT="Contact Form">
                  <node TEXT="Title Field" />
                  <node TEXT="Organization Field" />
                  <node TEXT="Email Field" />
                  <node TEXT="Phone Field" />
                  <node TEXT="Message Field" />
                  <node TEXT="Submit" />
                </node>
              </node>
            </node>
            <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" />
          </node>
        </node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/">
          <node TEXT="Workforce Reimagined">
            <node TEXT="A new era of work is here, blending flexibility, expertise, and innovation for business success." />
            <node TEXT="Read the Research Report" LINK="https://lionsandtigers.com/why-now/" />
          </node>
          <node TEXT="The American workforce is at an inflection point">
            <node TEXT="2023 research reveals a shift in how teams are structured and work is delivered." />
            <node TEXT="Blended teams drive innovation and resilience in organizations." />
            <node TEXT="Key data shows the value of specialized skills and flexible engagement." />
            <node TEXT="More teams are using blended models to meet business needs." />
          </node>
          <node TEXT="Why This Study">
            <node TEXT="This study explores the impact of blended teams on business outcomes and workforce trends." />
            <node TEXT="Brea Starmer" LINK="https://www.linkedin.com/in/breastarmer/" />
          </node>
          <node TEXT="Leadership Quote">
            <node TEXT="Leaders who prioritize flexibility and expertise will outperform those focused only on headcount." />
          </node>
          <node TEXT="The Data Is In: Blended Teams Work">
            <node TEXT="79% Specialized Skills = Competitive Edge" />
            <node TEXT="87% Quality Over Cost" />
            <node TEXT="Built for Speed &amp; Innovation" />
            <node TEXT="97% say losing access to blended teams would disrupt business outcomes." />
          </node>
          <node TEXT="The Value Compounds Over Time">
            <node TEXT="The longer a company employs blended teams, the more vital they become." />
          </node>
          <node TEXT="Expert Quote">
            <node TEXT="Blended teams are now an accepted and expected part of the workforce." />
          </node>
          <node TEXT="Why It Matters">
            <node TEXT="Blended teams are a strategic solution, not a temporary fix." />
            <node TEXT="They provide access to critical skills and support business growth." />
          </node>
          <node TEXT="The 2025 Blended Workforce Survey">
            <node TEXT="Research by Read the Room Advisors and Lions &amp; Tigers highlights the future of blended teams." />
            <node TEXT="Download Full Survey Report" LINK="https://lionsandtigers.com/why-now/" />
          </node>
        </node>
        <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/">
          <node TEXT="Hero Section">
            <node TEXT="Built For Fortune 500s &amp; Startups - We design the team &amp; solutions you need, powered by 100+ consultants." />
          </node>
          <node TEXT="Trusted Partnership">
            <node TEXT="Workforce solutions aligned to key outcomes, creating a plan that moves you and your team forward from day one." />
          </node>
          <node TEXT="Engagement Model Built for YOU">
            <node TEXT="Start with a conversation about your impact and project 'ask' to understand your business and goals." />
            <node TEXT="Model Types">
              <node TEXT="Full-time &amp; Fractional" />
              <node TEXT="Individuals &amp; Teams" />
              <node TEXT="Time &amp; Outcome Based" />
            </node>
            <node TEXT="Experience Table Summary">
              <node TEXT="Levels of experience and capabilities for strategic leaders, executives, and specialists." />
            </node>
          </node>
          <node TEXT="Capabilities &amp; Skillsets">
            <node TEXT="Communications &amp; Marketing" />
            <node TEXT="Operations" />
            <node TEXT="Change" />
          </node>
          <node TEXT="Client Stories">
            <node TEXT="Flexible consulting teams solve clients' biggest challenges using the Highest &amp; Best Use Operating System." />
            <node TEXT="I NEEDED: To scale myself &amp; level up my team" />
            <node TEXT="I NEEDED: My team to feel safe &amp; inclusive." />
            <node TEXT="I NEEDED: Product insights &amp; raving fans." />
            <node TEXT="I NEEDED: Flexibility &amp; less risk." />
            <node TEXT="I NEEDED: A sprint staff &amp; domain experts." />
          </node>
          <node TEXT="Clients &amp; Talent Actions">
            <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
            <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" />
          </node>
        </node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/">
          <node TEXT="Hero Section">
            <node TEXT="We are an inclusive community of marketing, comms, operations and change specialists who value high-impact work &amp; flexibility." />
            <node TEXT="EXPLORE OPEN ROLES" LINK="https://lionsandtigers.com/join-our-team/#open-roles" />
          </node>
          <node TEXT="Mission Statement">
            <node TEXT="We are re-writing what it means to be a great place to work." />
          </node>
          <node TEXT="What You Will Find">
            <node TEXT="Flexibility">
              <node TEXT="Work with great talent on your own schedule, whether it’s 5 or 40 hours a week." />
            </node>
            <node TEXT="Community">
              <node TEXT="Join, hands down, some of the best people we’ve ever worked with." />
            </node>
            <node TEXT="Values">
              <node TEXT="We set our values of community, impact, and adventure as our standards. Build a better and more equitable working world." />
            </node>
            <node TEXT="Resources &amp; Growth">
              <node TEXT="Benefits, best practices, mentorship, support, independent contractor support and more." />
            </node>
            <node TEXT="DEI">
              <node TEXT="We’re on a multi-year journey to do the work of building an inclusive anti-racist organization." />
              <node TEXT="more" LINK="https://lionsandtigers.com/dei" />
            </node>
            <node TEXT="Fun">
              <node TEXT="Virtual and in-person family picnics, holiday parties, happy hours &amp; coffee meetups." />
            </node>
          </node>
          <node TEXT="Awards &amp; Certifications">
            <node TEXT="2022 Washington’s Best Workplaces" />
            <node TEXT="Certified WBENC Women’s Business Enterprise" />
          </node>
          <node TEXT="Open Roles">
            <node TEXT="Section for open job opportunities (currently no roles listed)." />
          </node>
          <node TEXT="Talent Newsletter">
            <node TEXT="Be the first to hear of open roles, upcoming events and other talent news from Lions &amp; Tigers in our Role Call newsletter." />
            <node TEXT="Newsletter Form">
              <node TEXT="Email Address Field" />
              <node TEXT="SUBSCRIBE" LINK="https://lionsandtigers.com/newsletter/" />
            </node>
          </node>
          <node TEXT="Key Stats">
            <node TEXT="97.5% consultant retention rate" />
            <node TEXT="$34M paid out to Lions &amp; Tigers consultants" />
            <node TEXT="100% of our team works fully remote or hybrid" />
            <node TEXT="87% women (of those on our team who self-identify)" />
          </node>
          <node TEXT="What Happens After You Apply">
            <node TEXT="1. Apply for a role via an online application." />
            <node TEXT="2. Your application is reviewed by a real person." />
            <node TEXT="3. If you’re a fit, we will contact you for an initial call." />
            <node TEXT="4. You will not be ghosted!" />
            <node TEXT="CONSULTANT FAQ" LINK="https://lionsandtigers.com/consultant-faq/" />
          </node>
          <node TEXT="From Our Team">
            <node TEXT="Testimonial: Able to chart my own path and focus on what is important to me rather than moving a million miles a minute." />
          </node>
        </node>
        <node TEXT="Resources" LINK="https://lionsandtigers.com/">
          <node TEXT="Build Your Dream Team">
            <node TEXT="Highly skilled marketing, comms, operations &amp; change specialists ready to drive your business forward." />
            <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
          </node>
          <node TEXT="Our model fits your needs &amp; our people">
            <node TEXT="We design the solutions that fit your needs – today &amp; tomorrow." />
            <node TEXT="Full-time &amp; Fractional" />
            <node TEXT="Individuals &amp; Teams" />
            <node TEXT="Time &amp; Outcome Based" />
          </node>
          <node TEXT="A Word From Our Clients">
            <node TEXT="Clients praise the team for expertise, connections, and delivering on complex projects." />
          </node>
          <node TEXT="High Performance &amp; Belonging">
            <node TEXT="Playbook for leaders to maximize human potential and business outcomes while preventing burnout and exclusion." />
            <node TEXT="LEARN MORE" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" />
          </node>
          <node TEXT="Team Diversity">
            <node TEXT="Our team self-identifies as 87% women." />
          </node>
          <node TEXT="Vision &amp; Mission">
            <node TEXT="Vision: To unlock the full potential of the workforce." />
            <node TEXT="Mission: Strengthen businesses with blended, human-centered teams." />
            <node TEXT="OUR STORY" LINK="https://lionsandtigers.com/our-story/" />
          </node>
          <node TEXT="Clients">
            <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
          </node>
          <node TEXT="Talent">
            <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" />
          </node>
        </node>
      </node>
      <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" />
      <node TEXT="Resources" LINK="https://lionsandtigers.com/" />
      <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" />
      <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" />
      <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/" />
    </node>
    <node TEXT="Main Content">
      <node TEXT="Build Your Dream Team" />
      <node TEXT="Description" LINK="" />
      <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
    </node>
    <node TEXT="Footer">
      <node TEXT="Follow">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/lionsandtigers" />
        <node TEXT="Twitter" LINK="https://twitter.com/lionstigersco" />
        <node TEXT="Instagram" LINK="https://www.instagram.com/lionstigersco/" />
        <node TEXT="YouTube" LINK="https://www.youtube.com/@lionstigersco" />
      </node>
    </node>
  </node>
</map>