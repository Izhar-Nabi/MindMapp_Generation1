<node TEXT="resources">
    <node TEXT="Main Content">
      <node TEXT="Build Your Dream Team">
        <node TEXT="Highly skilled marketing, comms, operations &amp; change specialists ready to drive your business forward."/>
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/"/>
      </node>
      <node TEXT="Our model fits your needs &amp; our people">
        <node TEXT="We design the solutions that fit your needs – today &amp; tomorrow."/>
        <node TEXT="Full-time &amp; Fractional"/>
        <node TEXT="Individuals &amp; Teams"/>
        <node TEXT="Time &amp; Outcome Based"/>
      </node>
      <node TEXT="A Word From Our Clients">
        <node TEXT="Clients praise the team for expertise, connections, and delivering on complex projects."/>
      </node>
      <node TEXT="High Performance &amp; Belonging">
        <node TEXT="Playbook for leaders to maximize human potential and business outcomes while preventing burnout and exclusion."/>
        <node TEXT="LEARN MORE" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/"/>
      </node>
      <node TEXT="Team Diversity">
        <node TEXT="Our team self-identifies as 87% women."/>
      </node>
      <node TEXT="Vision &amp; Mission">
        <node TEXT="Vision: To unlock the full potential of the workforce."/>
        <node TEXT="Mission: Strengthen businesses with blended, human-centered teams."/>
        <node TEXT="OUR STORY" LINK="https://lionsandtigers.com/our-story/"/>
      </node>
      <node TEXT="Clients">
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/"/>
      </node>
      <node TEXT="Talent">
        <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/"/>
      </node>
    </node>
  </node>