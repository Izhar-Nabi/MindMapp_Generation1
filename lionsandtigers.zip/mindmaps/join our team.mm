<node TEXT="join our team">
    <node TEXT="Main Content">
      <node TEXT="Hero Section">
        <node TEXT="We are an inclusive community of marketing, comms, operations and change specialists who value high-impact work &amp; flexibility."/>
        <node TEXT="EXPLORE OPEN ROLES" LINK="https://lionsandtigers.com/join-our-team/#open-roles"/>
      </node>
      <node TEXT="Mission Statement">
        <node TEXT="We are re-writing what it means to be a great place to work."/>
      </node>
      <node TEXT="What You Will Find">
        <node TEXT="Flexibility">
          <node TEXT="Work with great talent on your own schedule, whether it’s 5 or 40 hours a week."/>
        </node>
        <node TEXT="Community">
          <node TEXT="Join, hands down, some of the best people we’ve ever worked with."/>
        </node>
        <node TEXT="Values">
          <node TEXT="We set our values of community, impact, and adventure as our standards. Build a better and more equitable working world."/>
        </node>
        <node TEXT="Resources &amp; Growth">
          <node TEXT="Benefits, best practices, mentorship, support, independent contractor support and more."/>
        </node>
        <node TEXT="DEI">
          <node TEXT="We’re on a multi-year journey to do the work of building an inclusive anti-racist organization."/>
          <node TEXT="more" LINK="https://lionsandtigers.com/dei"/>
        </node>
        <node TEXT="Fun">
          <node TEXT="Virtual and in-person family picnics, holiday parties, happy hours &amp; coffee meetups."/>
        </node>
      </node>
      <node TEXT="Awards &amp; Certifications">
        <node TEXT="2022 Washington’s Best Workplaces"/>
        <node TEXT="Certified WBENC Women’s Business Enterprise"/>
      </node>
      <node TEXT="Open Roles">
        <node TEXT="Section for open job opportunities (currently no roles listed)."/>
      </node>
      <node TEXT="Talent Newsletter">
        <node TEXT="Be the first to hear of open roles, upcoming events and other talent news from Lions &amp; Tigers in our Role Call newsletter."/>
        <node TEXT="Newsletter Form">
          <node TEXT="Email Address Field"/>
          <node TEXT="SUBSCRIBE" LINK="https://lionsandtigers.com/newsletter/"/>
        </node>
      </node>
      <node TEXT="Key Stats">
        <node TEXT="97.5% consultant retention rate"/>
        <node TEXT="$34M paid out to Lions &amp; Tigers consultants"/>
        <node TEXT="100% of our team works fully remote or hybrid"/>
        <node TEXT="87% women (of those on our team who self-identify)"/>
      </node>
      <node TEXT="What Happens After You Apply">
        <node TEXT="1. Apply for a role via an online application."/>
        <node TEXT="2. Your application is reviewed by a real person."/>
        <node TEXT="3. If you’re a fit, we will contact you for an initial call."/>
        <node TEXT="4. You will not be ghosted!"/>
        <node TEXT="CONSULTANT FAQ" LINK="https://lionsandtigers.com/consultant-faq/"/>
      </node>
      <node TEXT="From Our Team">
        <node TEXT="Testimonial: Able to chart my own path and focus on what is important to me rather than moving a million miles a minute."/>
      </node>
    </node>
  </node>