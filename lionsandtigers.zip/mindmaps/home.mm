<?xml version='1.0' encoding='utf-8'?>
<map version="0.9.0">
  <node TEXT="LIONS   TIGERS">
    <node TEXT="Header">
      <node TEXT="Navigation Links">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" />
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" />
        <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/" />
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" />
        <node TEXT="Resources" LINK="https://lionsandtigers.com/" />
      </node>
    </node>
    <node TEXT="Main Content">
      <node TEXT="Build Your Dream Team" />
      <node TEXT="Description" LINK="" />
      <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" />
    </node>
    <node TEXT="Footer">
      <node TEXT="Follow">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/lionsandtigers" />
        <node TEXT="Twitter" LINK="https://twitter.com/lionstigersco" />
        <node TEXT="Instagram" LINK="https://www.instagram.com/lionstigersco/" />
        <node TEXT="YouTube" LINK="https://www.youtube.com/@lionstigersco" />
      </node>
    </node>
  </node>
</map>