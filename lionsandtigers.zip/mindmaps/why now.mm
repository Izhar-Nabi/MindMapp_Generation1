<node TEXT="why now">
    <node TEXT="Main Content">
      <node TEXT="Workforce Reimagined">
        <node TEXT="A new era of work is here, blending flexibility, expertise, and innovation for business success."/>
        <node TEXT="Read the Research Report" LINK="https://lionsandtigers.com/why-now/"/>
      </node>
      <node TEXT="The American workforce is at an inflection point">
        <node TEXT="2023 research reveals a shift in how teams are structured and work is delivered."/>
        <node TEXT="Blended teams drive innovation and resilience in organizations."/>
        <node TEXT="Key data shows the value of specialized skills and flexible engagement."/>
        <node TEXT="More teams are using blended models to meet business needs."/>
      </node>
      <node TEXT="Why This Study">
        <node TEXT="This study explores the impact of blended teams on business outcomes and workforce trends."/>
        <node TEXT="Brea Starmer" LINK="https://www.linkedin.com/in/breastarmer/"/>
      </node>
      <node TEXT="Leadership Quote">
        <node TEXT="Leaders who prioritize flexibility and expertise will outperform those focused only on headcount."/>
      </node>
      <node TEXT="The Data Is In: Blended Teams Work">
        <node TEXT="79% Specialized Skills = Competitive Edge"/>
        <node TEXT="87% Quality Over Cost"/>
        <node TEXT="Built for Speed &amp; Innovation"/>
        <node TEXT="97% say losing access to blended teams would disrupt business outcomes."/>
      </node>
      <node TEXT="The Value Compounds Over Time">
        <node TEXT="The longer a company employs blended teams, the more vital they become."/>
      </node>
      <node TEXT="Expert Quote">
        <node TEXT="Blended teams are now an accepted and expected part of the workforce."/>
      </node>
      <node TEXT="Why It Matters">
        <node TEXT="Blended teams are a strategic solution, not a temporary fix."/>
        <node TEXT="They provide access to critical skills and support business growth."/>
      </node>
      <node TEXT="The 2025 Blended Workforce Survey">
        <node TEXT="Research by Read the Room Advisors and Lions &amp; Tigers highlights the future of blended teams."/>
        <node TEXT="Download Full Survey Report" LINK="https://lionsandtigers.com/why-now/"/>
      </node>
    </node>
  </node>