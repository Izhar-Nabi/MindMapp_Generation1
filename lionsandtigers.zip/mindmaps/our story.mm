<node TEXT="our story">
    <node TEXT="Main Content">
      <node TEXT="The Power of &amp;">
        <node TEXT="Fostering the power of and, these founders built a model of work where work &amp; life could be in harmony."/>
      </node>
      <node TEXT="Re-imagining Work &amp; Life">
        <node TEXT="How it all started: Building a new approach to work and life integration."/>
        <node TEXT="Key Beliefs">
          <node TEXT="It is time to reimagine a thriving, equitable, and engaged community of work and life."/>
          <node TEXT="We must build different &amp; better."/>
          <node TEXT="We must balance demands, mental nourishment, and impact."/>
          <node TEXT="To keep adapting AND create the power of &amp;."/>
        </node>
      </node>
      <node TEXT="Vision &amp; Mission">
        <node TEXT="Vision: To unlock the full potential of the workforce."/>
        <node TEXT="Mission: We strengthen businesses with the power of the independent workforce and diverse teams."/>
      </node>
      <node TEXT="Our Values">
        <node TEXT="These values stem from our focus on power, equity, and action, fueling how we work."/>
        <node TEXT="Community: We nurture a community that lifts one another up and prioritizes common access &amp; representation."/>
        <node TEXT="Impact: We seek the highest &amp; best ways, measuring success in outcomes not outputs."/>
        <node TEXT="Stewardship: We serve plus advocate, leaving all we touch better than we found them."/>
        <node TEXT="Courage: We lead with determination and resilience, pushing the boundaries of what is possible."/>
      </node>
      <node TEXT="Recent Recognition">
        <node TEXT="Awards and recognitions for impact and innovation."/>
      </node>
      <node TEXT="L&amp;T Talent Network">
        <node TEXT="A diverse network of professionals supporting the mission."/>
      </node>
      <node TEXT="Staff Team">
        <node TEXT="Brea Starmer, Founder, CEO">
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/breastarmer"/>
        </node>
        <node TEXT="Ashley Jude, President">
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/ashleyjude"/>
        </node>
        <node TEXT="Lorraine Cunningham, Chief Technology &amp; Financial Officer">
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/cunninghamlorraine"/>
        </node>
        <node TEXT="LaShunte Portrey, Business Development">
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/lashunteportrey/"/>
        </node>
        <node TEXT="Steven Rowe, Client Experience">
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/sttrowe"/>
        </node>
        <node TEXT="Reiko Kono, Client Experience Team">
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/reiko-kono-161056171/"/>
        </node>
        <node TEXT="Shannon Lee, Marketing">
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/shannon-lee13/"/>
        </node>
        <node TEXT="Nan Jackson, Client Experience">
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/nanbjackson"/>
        </node>
        <node TEXT="Miranda Leurquin, Talent Advocacy">
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mirandaleurquin/"/>
        </node>
        <node TEXT="Jocylynn Kelley, Talent Advocacy">
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/jocylynn-kelley/"/>
        </node>
        <node TEXT="Allison Monat, Talent Advocacy">
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/allisonsmonat"/>
        </node>
        <node TEXT="Mercedes Dunn, Talent Advocacy">
          <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mercedesdunn/"/>
        </node>
      </node>
      <node TEXT="Clients &amp; Talent Actions">
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/"/>
        <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/"/>
      </node>
    </node>
  </node>