<node TEXT="solutions">
    <node TEXT="Main Content">
      <node TEXT="Hero Section">
        <node TEXT="Built For Fortune 500s &amp; Startups - We design the team &amp; solutions you need, powered by 100+ consultants."/>
      </node>
      <node TEXT="Trusted Partnership">
        <node TEXT="Workforce solutions aligned to key outcomes, creating a plan that moves you and your team forward from day one."/>
      </node>
      <node TEXT="Engagement Model Built for YOU">
        <node TEXT="Start with a conversation about your impact and project 'ask' to understand your business and goals."/>
        <node TEXT="Model Types">
          <node TEXT="Full-time &amp; Fractional"/>
          <node TEXT="Individuals &amp; Teams"/>
          <node TEXT="Time &amp; Outcome Based"/>
        </node>
        <node TEXT="Experience Table Summary">
          <node TEXT="Levels of experience and capabilities for strategic leaders, executives, and specialists."/>
        </node>
      </node>
      <node TEXT="Capabilities &amp; Skillsets">
        <node TEXT="Communications &amp; Marketing"/>
        <node TEXT="Operations"/>
        <node TEXT="Change"/>
      </node>
      <node TEXT="Client Stories">
        <node TEXT="Flexible consulting teams solve clients&apos; biggest challenges using the Highest &amp; Best Use Operating System."/>
        <node TEXT="I NEEDED: To scale myself &amp; level up my team"/>
        <node TEXT="I NEEDED: My team to feel safe &amp; inclusive."/>
        <node TEXT="I NEEDED: Product insights &amp; raving fans."/>
        <node TEXT="I NEEDED: Flexibility &amp; less risk."/>
        <node TEXT="I NEEDED: A sprint staff &amp; domain experts."/>
      </node>
      <node TEXT="Clients &amp; Talent Actions">
        <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/"/>
        <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/"/>
      </node>
    </node>
  </node>