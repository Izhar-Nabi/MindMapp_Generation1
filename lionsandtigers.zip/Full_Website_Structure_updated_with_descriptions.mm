<?xml version='1.0' encoding='UTF-8'?>
<map version="0.9.0">
  <node TEXT="Home Page" FOLDED="true">
    <node TEXT="Header" FOLDED="true">
      <node TEXT="Navigation Links" FOLDED="true">
        <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" FOLDED="true">
          <node TEXT="The Power of &amp;" FOLDED="true">
            <node TEXT="Fostering the power of and, these founders built a model of work where work &amp; life could be in harmony." FOLDED="true"/>
          </node>
          <node TEXT="Re-imagining Work &amp; Life" FOLDED="true">
            <node TEXT="How it all started: Building a new approach to work and life integration." FOLDED="true"/>
            <node TEXT="Key Beliefs" FOLDED="true">
              <node TEXT="It is time to reimagine a thriving, equitable, and engaged community of work and life." FOLDED="true"/>
              <node TEXT="We must build different &amp; better." FOLDED="true"/>
              <node TEXT="We must balance demands, mental nourishment, and impact." FOLDED="true"/>
              <node TEXT="To keep adapting AND create the power of &amp;." FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Vision &amp; Mission" FOLDED="true">
            <node TEXT="Vision: To unlock the full potential of the workforce." FOLDED="true"/>
            <node TEXT="Mission: We strengthen businesses with the power of the independent workforce and diverse teams." FOLDED="true"/>
          </node>
          <node TEXT="Our Values" FOLDED="true">
            <node TEXT="These values stem from our focus on power, equity, and action, fueling how we work." FOLDED="true"/>
            <node TEXT="Community: We nurture a community that lifts one another up and prioritizes common access &amp; representation." FOLDED="true"/>
            <node TEXT="Impact: We seek the highest &amp; best ways, measuring success in outcomes not outputs." FOLDED="true"/>
            <node TEXT="Stewardship: We serve plus advocate, leaving all we touch better than we found them." FOLDED="true"/>
            <node TEXT="Courage: We lead with determination and resilience, pushing the boundaries of what is possible." FOLDED="true"/>
          </node>
          <node TEXT="Recent Recognition" FOLDED="true">
            <node TEXT="Awards and recognitions for impact and innovation." FOLDED="true"/>
          </node>
          <node TEXT="L&amp;T Talent Network" FOLDED="true">
            <node TEXT="A diverse network of professionals supporting the mission." FOLDED="true"/>
          </node>
          <node TEXT="Staff Team" FOLDED="true">
            <node TEXT="Brea Starmer, Founder, CEO" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/breastarmer" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Ashley Jude, President" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/ashleyjude" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_ashleyjude.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Lorraine Cunningham, Chief Technology &amp; Financial Officer" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/cunninghamlorraine" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_cunninghamlorraine.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="LaShunte Portrey, Business Development" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/lashunteportrey/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_lashunteportrey.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Steven Rowe, Client Experience" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/sttrowe" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_sttrowe.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Reiko Kono, Client Experience Team" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/reiko-kono-161056171/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_reiko-kono-161056171.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Shannon Lee, Marketing" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/shannon-lee13/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_shannon-lee13.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Nan Jackson, Client Experience" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/nanbjackson" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_nanbjackson.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Miranda Leurquin, Talent Advocacy" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mirandaleurquin/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_mirandaleurquin.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Jocylynn Kelley, Talent Advocacy" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/jocylynn-kelley/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_jocylynn-kelley.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Allison Monat, Talent Advocacy" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/allisonsmonat" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_allisonsmonat.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Mercedes Dunn, Talent Advocacy" FOLDED="true">
              <node TEXT="LinkedIn" LINK="https://www.linkedin.com/in/mercedesdunn/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_mercedesdunn.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Clients &amp; Talent Actions" FOLDED="true">
            <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true">
              <node TEXT="Main Content" FOLDED="true">
                <node TEXT="Intro" FOLDED="true">
                  <node TEXT="Interested in hiring our consultants? Complete this form and we’ll be in touch shortly." FOLDED="true"/>
                  <node TEXT="Interested in joining our team of consultants? Learn more here." LINK="https://lionsandtigers.com/join-our-team" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
                </node>
                <node TEXT="Contact Form" FOLDED="true">
                  <node TEXT="Title Field" FOLDED="true"/>
                  <node TEXT="Organization Field" FOLDED="true"/>
                  <node TEXT="Email Field" FOLDED="true"/>
                  <node TEXT="Phone Field" FOLDED="true"/>
                  <node TEXT="Message Field" FOLDED="true"/>
                  <node TEXT="Submit" FOLDED="true"/>
                </node>
              </node>
            <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" FOLDED="true">
          <node TEXT="Workforce Reimagined" FOLDED="true">
            <node TEXT="A new era of work is here, blending flexibility, expertise, and innovation for business success." FOLDED="true"/>
            <node TEXT="Read the Research Report" LINK="https://lionsandtigers.com/why-now/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="The American workforce is at an inflection point" FOLDED="true">
            <node TEXT="2023 research reveals a shift in how teams are structured and work is delivered." FOLDED="true"/>
            <node TEXT="Blended teams drive innovation and resilience in organizations." FOLDED="true"/>
            <node TEXT="Key data shows the value of specialized skills and flexible engagement." FOLDED="true"/>
            <node TEXT="More teams are using blended models to meet business needs." FOLDED="true"/>
          </node>
          <node TEXT="Why This Study" FOLDED="true">
            <node TEXT="This study explores the impact of blended teams on business outcomes and workforce trends." FOLDED="true"/>
            <node TEXT="Brea Starmer" LINK="https://www.linkedin.com/in/breastarmer/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_in_breastarmer.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Leadership Quote" FOLDED="true">
            <node TEXT="Leaders who prioritize flexibility and expertise will outperform those focused only on headcount." FOLDED="true"/>
          </node>
          <node TEXT="The Data Is In: Blended Teams Work" FOLDED="true">
            <node TEXT="79% Specialized Skills = Competitive Edge" FOLDED="true"/>
            <node TEXT="87% Quality Over Cost" FOLDED="true"/>
            <node TEXT="Built for Speed &amp; Innovation" FOLDED="true"/>
            <node TEXT="97% say losing access to blended teams would disrupt business outcomes." FOLDED="true"/>
          </node>
          <node TEXT="The Value Compounds Over Time" FOLDED="true">
            <node TEXT="The longer a company employs blended teams, the more vital they become." FOLDED="true"/>
          </node>
          <node TEXT="Expert Quote" FOLDED="true">
            <node TEXT="Blended teams are now an accepted and expected part of the workforce." FOLDED="true"/>
          </node>
          <node TEXT="Why It Matters" FOLDED="true">
            <node TEXT="Blended teams are a strategic solution, not a temporary fix." FOLDED="true"/>
            <node TEXT="They provide access to critical skills and support business growth." FOLDED="true"/>
          </node>
          <node TEXT="The 2025 Blended Workforce Survey" FOLDED="true">
            <node TEXT="Research by Read the Room Advisors and Lions &amp; Tigers highlights the future of blended teams." FOLDED="true"/>
            <node TEXT="Download Full Survey Report" LINK="https://lionsandtigers.com/why-now/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/" FOLDED="true">
          <node TEXT="Hero Section" FOLDED="true">
            <node TEXT="Built For Fortune 500s &amp; Startups - We design the team &amp; solutions you need, powered by 100+ consultants." FOLDED="true"/>
          </node>
          <node TEXT="Trusted Partnership" FOLDED="true">
            <node TEXT="Workforce solutions aligned to key outcomes, creating a plan that moves you and your team forward from day one." FOLDED="true"/>
          </node>
          <node TEXT="Engagement Model Built for YOU" FOLDED="true">
            <node TEXT="Start with a conversation about your impact and project 'ask' to understand your business and goals." FOLDED="true"/>
            <node TEXT="Model Types" FOLDED="true">
              <node TEXT="Full-time &amp; Fractional" FOLDED="true"/>
              <node TEXT="Individuals &amp; Teams" FOLDED="true"/>
              <node TEXT="Time &amp; Outcome Based" FOLDED="true"/>
            </node>
            <node TEXT="Experience Table Summary" FOLDED="true">
              <node TEXT="Levels of experience and capabilities for strategic leaders, executives, and specialists." FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Capabilities &amp; Skillsets" FOLDED="true">
            <node TEXT="Communications &amp; Marketing" FOLDED="true"/>
            <node TEXT="Operations" FOLDED="true"/>
            <node TEXT="Change" FOLDED="true"/>
          </node>
          <node TEXT="Client Stories" FOLDED="true">
            <node TEXT="Flexible consulting teams solve clients' biggest challenges using the Highest &amp; Best Use Operating System." FOLDED="true"/>
            <node TEXT="I NEEDED: To scale myself &amp; level up my team" FOLDED="true"/>
            <node TEXT="I NEEDED: My team to feel safe &amp; inclusive." FOLDED="true"/>
            <node TEXT="I NEEDED: Product insights &amp; raving fans." FOLDED="true"/>
            <node TEXT="I NEEDED: Flexibility &amp; less risk." FOLDED="true"/>
            <node TEXT="I NEEDED: A sprint staff &amp; domain experts." FOLDED="true"/>
          </node>
          <node TEXT="Clients &amp; Talent Actions" FOLDED="true">
            <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true">
          <node TEXT="Hero Section" FOLDED="true">
            <node TEXT="We are an inclusive community of marketing, comms, operations and change specialists who value high-impact work &amp; flexibility." FOLDED="true"/>
            <node TEXT="EXPLORE OPEN ROLES" LINK="https://lionsandtigers.com/join-our-team/#open-roles" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team_open-roles.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Mission Statement" FOLDED="true">
            <node TEXT="We are re-writing what it means to be a great place to work." FOLDED="true"/>
          </node>
          <node TEXT="What You Will Find" FOLDED="true">
            <node TEXT="Flexibility" FOLDED="true">
              <node TEXT="Work with great talent on your own schedule, whether it’s 5 or 40 hours a week." FOLDED="true"/>
            </node>
            <node TEXT="Community" FOLDED="true">
              <node TEXT="Join, hands down, some of the best people we’ve ever worked with." FOLDED="true"/>
            </node>
            <node TEXT="Values" FOLDED="true">
              <node TEXT="We set our values of community, impact, and adventure as our standards. Build a better and more equitable working world." FOLDED="true"/>
            </node>
            <node TEXT="Resources &amp; Growth" FOLDED="true">
              <node TEXT="Benefits, best practices, mentorship, support, independent contractor support and more." FOLDED="true"/>
            </node>
            <node TEXT="DEI" FOLDED="true">
              <node TEXT="We’re on a multi-year journey to do the work of building an inclusive anti-racist organization." FOLDED="true"/>
              <node TEXT="more" LINK="https://lionsandtigers.com/dei" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_dei.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
            <node TEXT="Fun" FOLDED="true">
              <node TEXT="Virtual and in-person family picnics, holiday parties, happy hours &amp; coffee meetups." FOLDED="true"/>
            </node>
          </node>
          <node TEXT="Awards &amp; Certifications" FOLDED="true">
            <node TEXT="2022 Washington’s Best Workplaces" FOLDED="true"/>
            <node TEXT="Certified WBENC Women’s Business Enterprise" FOLDED="true"/>
          </node>
          <node TEXT="Open Roles" FOLDED="true">
            <node TEXT="Section for open job opportunities (currently no roles listed)." FOLDED="true"/>
          </node>
          <node TEXT="Talent Newsletter" FOLDED="true">
            <node TEXT="Be the first to hear of open roles, upcoming events and other talent news from Lions &amp; Tigers in our Role Call newsletter." FOLDED="true"/>
            <node TEXT="Newsletter Form" FOLDED="true">
              <node TEXT="Email Address Field" FOLDED="true"/>
              <node TEXT="SUBSCRIBE" LINK="https://lionsandtigers.com/newsletter/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_newsletter.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
            </node>
          </node>
          <node TEXT="Key Stats" FOLDED="true">
            <node TEXT="97.5% consultant retention rate" FOLDED="true"/>
            <node TEXT="$34M paid out to Lions &amp; Tigers consultants" FOLDED="true"/>
            <node TEXT="100% of our team works fully remote or hybrid" FOLDED="true"/>
            <node TEXT="87% women (of those on our team who self-identify)" FOLDED="true"/>
          </node>
          <node TEXT="What Happens After You Apply" FOLDED="true">
            <node TEXT="1. Apply for a role via an online application." FOLDED="true"/>
            <node TEXT="2. Your application is reviewed by a real person." FOLDED="true"/>
            <node TEXT="3. If you’re a fit, we will contact you for an initial call." FOLDED="true"/>
            <node TEXT="4. You will not be ghosted!" FOLDED="true"/>
            <node TEXT="CONSULTANT FAQ" LINK="https://lionsandtigers.com/consultant-faq/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_consultant-faq.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="From Our Team" FOLDED="true">
            <node TEXT="Testimonial: Able to chart my own path and focus on what is important to me rather than moving a million miles a minute." FOLDED="true"/>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Resources" LINK="https://lionsandtigers.com/" FOLDED="true">
          <node TEXT="Build Your Dream Team" FOLDED="true">
            <node TEXT="Highly skilled marketing, comms, operations &amp; change specialists ready to drive your business forward." FOLDED="true"/>
            <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Our model fits your needs &amp; our people" FOLDED="true">
            <node TEXT="We design the solutions that fit your needs – today &amp; tomorrow." FOLDED="true"/>
            <node TEXT="Full-time &amp; Fractional" FOLDED="true"/>
            <node TEXT="Individuals &amp; Teams" FOLDED="true"/>
            <node TEXT="Time &amp; Outcome Based" FOLDED="true"/>
          </node>
          <node TEXT="A Word From Our Clients" FOLDED="true">
            <node TEXT="Clients praise the team for expertise, connections, and delivering on complex projects." FOLDED="true"/>
          </node>
          <node TEXT="High Performance &amp; Belonging" FOLDED="true">
            <node TEXT="Playbook for leaders to maximize human potential and business outcomes while preventing burnout and exclusion." FOLDED="true"/>
            <node TEXT="LEARN MORE" LINK="https://lionsandtigers.com/avoiding-the-all-or-nothing-workplace/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_avoiding-the-all-or-nothing-workplace.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Team Diversity" FOLDED="true">
            <node TEXT="Our team self-identifies as 87% women." FOLDED="true"/>
          </node>
          <node TEXT="Vision &amp; Mission" FOLDED="true">
            <node TEXT="Vision: To unlock the full potential of the workforce." FOLDED="true"/>
            <node TEXT="Mission: Strengthen businesses with blended, human-centered teams." FOLDED="true"/>
            <node TEXT="OUR STORY" LINK="https://lionsandtigers.com/our-story/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Clients" FOLDED="true">
            <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
          <node TEXT="Talent" FOLDED="true">
            <node TEXT="JOIN OUR TEAM" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
          </node>
        <node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
      <node TEXT="Join Our Team" LINK="https://lionsandtigers.com/join-our-team/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_join-our-team.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Resources" LINK="https://lionsandtigers.com/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Our Story" LINK="https://lionsandtigers.com/our-story/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_our-story.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Why Now" LINK="https://lionsandtigers.com/why-now/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_why-now.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      <node TEXT="Solutions" LINK="https://lionsandtigers.com/solutions/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_solutions.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Main Content" FOLDED="true">
      <node TEXT="Build Your Dream Team" FOLDED="true"/>
      <node TEXT="Description" LINK="" FOLDED="true"/>
      <node TEXT="TALK TO US" LINK="https://lionsandtigers.com/talk-to-us/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_lionsandtigers.com_talk-to-us.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
    </node>
    <node TEXT="Footer" FOLDED="true">
      <node TEXT="Follow" FOLDED="true">
        <node TEXT="LinkedIn" LINK="https://www.linkedin.com/company/lionsandtigers" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.linkedin.com_company_lionsandtigers.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Twitter" LINK="https://twitter.com/lionstigersco" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_twitter.com_lionstigersco.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="Instagram" LINK="https://www.instagram.com/lionstigersco/" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.instagram.com_lionstigersco.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
        <node TEXT="YouTube" LINK="https://www.youtube.com/@lionstigersco" FOLDED="true"><node TEXT="Screenshot Example" FOLDED="true"><richcontent TYPE="NODE"><html>
    <body>
        <p>
        <img src="hyperlink_screenshots/https_www.youtube.com_lionstigersco.png" width="950" height="500"/>
        </p>
    </body>
    </html></richcontent></node></node>
      </node>
    </node>
  </node>
</map>
